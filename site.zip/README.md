# MCP Dashboard Review

Public, static review edition of the dev-center MCP Tools Dashboard.

- 14 documented tools across Topology, Info Center, and Skills.
- Search, filters, tool details, connection examples, and usage guides.
- No live MCP connection. The displayed endpoint is deliberately nonfunctional.
- Infrastructure strings are placeholders; remaining example values are illustrative.
- Contains compiled website files only, not development source or credentials.

This package is built for the `/mcp-dashboard-review/` base path.
Serve the repository root with GitHub Pages. `.nojekyll` preserves Next.js assets.

This is a public review, not an access-controlled internal service. Do not add credentials or private data.
